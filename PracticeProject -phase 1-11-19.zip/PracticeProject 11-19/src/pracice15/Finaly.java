package pracice15;

public class Finaly {
    public static void main(String[] args)
    {
        int a=45,b=0,rs=0;
        try
        {
            rs = a / b;
        }
        catch(ArithmeticException Ex)
        {
            System.out.print("Error is : " + Ex.getMessage());
        }
        finally
        {
            System.out.print("\nResult is : " + rs);
        }
    }

}
